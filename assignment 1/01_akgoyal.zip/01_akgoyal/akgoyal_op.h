float add (float x, float y);
int add (int x, int y);

float subtract (float x, float y);
int subtract (int x, int y);

float multiply (float x, float y);
int multiply (int x, int y);

float divide (float x, float y);

int mod (int x, int y);